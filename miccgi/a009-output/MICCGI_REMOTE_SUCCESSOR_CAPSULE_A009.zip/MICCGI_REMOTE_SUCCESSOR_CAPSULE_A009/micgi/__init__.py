"""MICCGI Recursive Capability Kernel.

This package does not claim MICCGI admission. It provides an executable substrate for
measured capability acquisition, successor construction, and falsifiable promotion.
"""

__version__ = "0.2.0"
