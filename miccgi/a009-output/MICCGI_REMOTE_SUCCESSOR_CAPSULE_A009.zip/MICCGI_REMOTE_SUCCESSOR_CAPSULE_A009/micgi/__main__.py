from micgi.cli import main
raise SystemExit(main())
