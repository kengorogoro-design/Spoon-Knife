from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

from micgi.evidence import Evidence
from micgi.model import CapabilityClaim


@dataclass(frozen=True)
class ProbeResult:
    capability_id: str
    claims: tuple[CapabilityClaim, ...]
    evidence: tuple[Evidence, ...]
    executable_spec: dict[str, Any]
    usable: bool = True


class CapabilityAdapter(ABC):
    capability_id: str

    @abstractmethod
    def probe(self) -> ProbeResult:
        raise NotImplementedError
