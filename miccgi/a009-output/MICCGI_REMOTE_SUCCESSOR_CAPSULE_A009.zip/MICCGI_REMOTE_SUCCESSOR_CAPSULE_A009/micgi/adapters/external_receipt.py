from __future__ import annotations

from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
from typing import Any

from micgi.adapters.base import CapabilityAdapter, ProbeResult
from micgi.evidence import Evidence, EvidenceClass
from micgi.model import CapabilityClaim, Direction


class ExternalReceiptAdapter(CapabilityAdapter):
    """Admit externally measured capability from a strict round-trip receipt.

    The receipt is an attestation boundary between a connector/orchestrator that can
    actually touch external Reality and the small local succession kernel. A receipt is
    not independent proof by itself. It is only admitted when its internal round-trip
    invariants are complete and it is explicitly scoped as external measured evidence.
    """

    def __init__(self, receipt_path: Path):
        self.receipt_path = receipt_path
        self.spec: dict[str, Any] = json.loads(receipt_path.read_text(encoding="utf-8"))
        self.capability_id = str(self.spec.get("capability_id", f"invalid:{receipt_path.name}"))

    def _validation_errors(self) -> list[str]:
        s = self.spec
        errors: list[str] = []
        required = [
            "receipt_version", "capability_id", "provider", "resource_id",
            "expected_nonce_sha256", "write", "readbacks", "claims",
            "executable_spec", "receipt_sha256",
        ]
        for key in required:
            if key not in s:
                errors.append(f"missing:{key}")

        if errors:
            return errors
        if int(s["receipt_version"]) != 1:
            errors.append("unsupported_receipt_version")

        check = deepcopy(s)
        supplied_hash = str(check.pop("receipt_sha256"))
        raw = json.dumps(check, sort_keys=True, separators=(",", ":")).encode()
        actual_hash = sha256(raw).hexdigest()
        if supplied_hash != actual_hash:
            errors.append("receipt_sha256_mismatch")

        resource_id = str(s["resource_id"])
        nonce = str(s["expected_nonce_sha256"])
        write = s.get("write") or {}
        write_hash = str(write.get("canonical_observation_sha256", ""))
        if str(write.get("resource_id", "")) != resource_id:
            errors.append("write_resource_mismatch")
        if not write_hash:
            errors.append("missing_write_observation_hash")

        readbacks = s.get("readbacks") or []
        if len(readbacks) < 2:
            errors.append("insufficient_readback_paths")
        methods: set[str] = set()
        for i, rb in enumerate(readbacks):
            method = str(rb.get("method", ""))
            methods.add(method)
            if str(rb.get("resource_id", "")) != resource_id:
                errors.append(f"readback_{i}_resource_mismatch")
            if str(rb.get("nonce_sha256", "")) != nonce:
                errors.append(f"readback_{i}_nonce_mismatch")
            if str(rb.get("canonical_observation_sha256", "")) != write_hash:
                errors.append(f"readback_{i}_observation_mismatch")
        if len(methods) < 2:
            errors.append("readback_methods_not_independent")

        claims = s.get("claims") or []
        if not claims:
            errors.append("no_claims")
        for i, claim in enumerate(claims):
            try:
                Direction(str(claim.get("direction", "true")))
                float(claim["value"])
                str(claim["name"])
            except Exception:
                errors.append(f"claim_{i}_invalid")

        exec_spec = s.get("executable_spec") or {}
        if exec_spec.get("type") != "orchestrated_connector":
            errors.append("external_capability_not_orchestrated_connector")
        if str(exec_spec.get("provider", "")) != str(s["provider"]):
            errors.append("provider_mismatch")
        if not exec_spec.get("actions"):
            errors.append("missing_external_actions")
        return errors

    def probe(self) -> ProbeResult:
        errors = self._validation_errors()
        receipt_digest = sha256(self.receipt_path.read_bytes()).hexdigest()
        if errors:
            payload = {
                "receipt_path": str(self.receipt_path),
                "receipt_file_sha256": receipt_digest,
                "validation_errors": errors,
            }
            ev = Evidence.create(
                EvidenceClass.LOCAL_MEASURED,
                self.capability_id,
                "external receipt rejected",
                payload,
            )
            return ProbeResult(self.capability_id, (), (ev,), {}, False)

        payload = {
            "receipt_path": str(self.receipt_path),
            "receipt_file_sha256": receipt_digest,
            "receipt": self.spec,
            "attestation_scope": "connector-orchestrated external round trip; not independent verification",
        }
        ev = Evidence.create(
            EvidenceClass.EXTERNAL_MEASURED,
            self.capability_id,
            "external persistent round-trip observed",
            payload,
        )
        claims: list[CapabilityClaim] = []
        for raw in self.spec["claims"]:
            claims.append(
                CapabilityClaim(
                    name=str(raw["name"]),
                    value=float(raw["value"]),
                    unit=str(raw.get("unit", "bool")),
                    direction=Direction(str(raw.get("direction", "true"))),
                    evidence_ids=(ev.evidence_id,),
                    durability=str(raw.get("durability", "external")),
                    objective_relevance=str(raw.get("objective_relevance", "supporting")),
                    metadata={
                        "provider": self.spec["provider"],
                        "resource_id": self.spec["resource_id"],
                        "receipt_sha256": self.spec["receipt_sha256"],
                        "attestation_scope": "session_orchestrated",
                    },
                )
            )
        executable_spec = dict(self.spec["executable_spec"])
        executable_spec.update({
            "resource_id": self.spec["resource_id"],
            "resource_url": self.spec.get("resource_url"),
            "evidence_ids": [ev.evidence_id],
            "required_evidence_class": EvidenceClass.EXTERNAL_MEASURED.value,
            "receipt_sha256": self.spec["receipt_sha256"],
        })
        return ProbeResult(
            self.capability_id,
            tuple(claims),
            (ev,),
            executable_spec,
            True,
        )


def discover_external_receipt_adapters(directory: Path) -> list[ExternalReceiptAdapter]:
    if not directory.exists():
        return []
    out: list[ExternalReceiptAdapter] = []
    for path in sorted(directory.glob("*.json")):
        try:
            out.append(ExternalReceiptAdapter(path))
        except Exception:
            # Invalid JSON cannot become capability. The file remains available for inspection.
            continue
    return out
