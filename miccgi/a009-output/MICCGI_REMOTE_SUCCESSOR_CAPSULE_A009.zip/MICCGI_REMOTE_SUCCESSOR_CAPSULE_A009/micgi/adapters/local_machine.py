from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

from micgi.adapters.base import CapabilityAdapter, ProbeResult
from micgi.evidence import Evidence, EvidenceClass
from micgi.model import CapabilityClaim, Direction


class LocalMachineAdapter(CapabilityAdapter):
    capability_id = "local.machine"

    def probe(self) -> ProbeResult:
        disk = shutil.disk_usage(Path.cwd())
        payload = {
            "python": sys.version,
            "platform": platform.platform(),
            "cpu_count": os.cpu_count() or 1,
            "disk_free_bytes": disk.free,
        }
        ev = Evidence.create(EvidenceClass.LOCAL_MEASURED, self.capability_id, "local machine resources", payload)
        claims = (
            CapabilityClaim("compute.cpu.logical_count", float(payload["cpu_count"]), "count", Direction.HIGHER_IS_BETTER, (ev.evidence_id,), "session", "supporting"),
            CapabilityClaim("storage.free_bytes", float(payload["disk_free_bytes"]), "bytes", Direction.HIGHER_IS_BETTER, (ev.evidence_id,), "session", "supporting"),
            CapabilityClaim("runtime.python.available", 1.0, "bool", Direction.BOOLEAN_TRUE, (ev.evidence_id,), "session", "direct"),
        )
        return ProbeResult(self.capability_id, claims, (ev,), {"type": "builtin", "adapter": self.capability_id}, True)


class CommandAdapter(CapabilityAdapter):
    def __init__(self, command: str, version_args: tuple[str, ...] = ("--version",)):
        self.command = command
        self.version_args = version_args
        self.capability_id = f"local.command.{command}"

    def probe(self) -> ProbeResult:
        path = shutil.which(self.command)
        if not path:
            raise FileNotFoundError(self.command)
        cp = subprocess.run([path, *self.version_args], capture_output=True, text=True, timeout=10, check=False)
        output = (cp.stdout or cp.stderr).strip()[:4000]
        payload = {"path": path, "returncode": cp.returncode, "version_output": output}
        ev = Evidence.create(EvidenceClass.LOCAL_MEASURED, self.capability_id, f"{self.command} executable probe", payload)
        ok = 1.0 if cp.returncode == 0 else 0.0
        claim = CapabilityClaim(
            name=f"executable.{self.command}.available",
            value=ok,
            unit="bool",
            direction=Direction.BOOLEAN_TRUE,
            evidence_ids=(ev.evidence_id,),
            durability="host",
            objective_relevance="supporting",
            metadata={"path": path, "probe": list(self.version_args)},
        )
        return ProbeResult(
            self.capability_id,
            (claim,),
            (ev,),
            {"type": "command", "path": path, "default_probe": list(self.version_args)},
            cp.returncode == 0,
        )
