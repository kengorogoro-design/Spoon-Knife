from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

from micgi.adapters.base import CapabilityAdapter, ProbeResult
from micgi.evidence import Evidence, EvidenceClass
from micgi.model import CapabilityClaim, Direction


class ManifestCapabilityAdapter(CapabilityAdapter):
    """Open capability adapter defined by data, not kernel code.

    A successor or external builder can add a manifest + executable and the kernel can
    measure/admit it without adding a new hard-coded capability category.
    """

    def __init__(self, manifest_path: Path):
        self.manifest_path = manifest_path
        self.spec: dict[str, Any] = json.loads(manifest_path.read_text(encoding="utf-8"))
        self.capability_id = str(self.spec["capability_id"])

    def probe(self) -> ProbeResult:
        argv = [str(x) for x in self.spec["probe_argv"]]
        cwd = self.spec.get("cwd")
        cp = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, timeout=float(self.spec.get("timeout_seconds", 15)), check=False)
        payload = {
            "manifest": str(self.manifest_path),
            "argv": argv,
            "returncode": cp.returncode,
            "stdout": cp.stdout[:8000],
            "stderr": cp.stderr[:8000],
        }
        ev = Evidence.create(EvidenceClass.LOCAL_MEASURED, self.capability_id, "manifest capability probe", payload)
        usable = cp.returncode == int(self.spec.get("success_returncode", 0))
        claims: list[CapabilityClaim] = []
        for raw in self.spec.get("claims", []):
            direction = Direction(raw.get("direction", "true"))
            if raw.get("value_from") == "probe_success":
                value = 1.0 if usable else 0.0
            else:
                value = float(raw["value"])
            claims.append(
                CapabilityClaim(
                    name=str(raw["name"]),
                    value=value,
                    unit=str(raw.get("unit", "bool")),
                    direction=direction,
                    evidence_ids=(ev.evidence_id,),
                    durability=str(raw.get("durability", "host")),
                    objective_relevance=str(raw.get("objective_relevance", "supporting")),
                    metadata={"manifest": str(self.manifest_path)},
                )
            )
        return ProbeResult(
            capability_id=self.capability_id,
            claims=tuple(claims),
            evidence=(ev,),
            executable_spec=dict(self.spec.get("executable_spec", {"type": "manifest", "manifest": str(self.manifest_path)})),
            usable=usable,
        )


def discover_manifest_adapters(directory: Path) -> list[ManifestCapabilityAdapter]:
    if not directory.exists():
        return []
    adapters: list[ManifestCapabilityAdapter] = []
    for path in sorted(directory.glob("*.json")):
        try:
            adapters.append(ManifestCapabilityAdapter(path))
        except Exception:
            continue
    return adapters
