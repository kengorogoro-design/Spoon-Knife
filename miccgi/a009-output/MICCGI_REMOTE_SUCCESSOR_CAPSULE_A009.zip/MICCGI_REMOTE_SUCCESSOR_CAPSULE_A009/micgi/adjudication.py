from __future__ import annotations

from dataclasses import dataclass, field

from micgi.evidence import EvidenceClass, EvidenceStore
from micgi.model import CapabilityClaim, Direction, GenerationState


@dataclass
class AdjudicationResult:
    admitted: bool
    reasons: list[str] = field(default_factory=list)
    improvements: list[str] = field(default_factory=list)
    regressions: list[str] = field(default_factory=list)


def _better(candidate: CapabilityClaim, parent: CapabilityClaim) -> bool:
    if candidate.direction != parent.direction or candidate.unit != parent.unit:
        return False
    if candidate.direction == Direction.HIGHER_IS_BETTER:
        return candidate.value > parent.value
    if candidate.direction == Direction.LOWER_IS_BETTER:
        return candidate.value < parent.value
    if candidate.direction == Direction.BOOLEAN_TRUE:
        return candidate.value >= 1 and parent.value < 1
    return False


def _worse(candidate: CapabilityClaim, parent: CapabilityClaim) -> bool:
    if candidate.direction != parent.direction or candidate.unit != parent.unit:
        return False
    if candidate.direction == Direction.HIGHER_IS_BETTER:
        return candidate.value < parent.value
    if candidate.direction == Direction.LOWER_IS_BETTER:
        return candidate.value > parent.value
    if candidate.direction == Direction.BOOLEAN_TRUE:
        return candidate.value < parent.value
    return False


def adjudicate_successor(parent: GenerationState, candidate: GenerationState, evidence_store: EvidenceStore) -> AdjudicationResult:
    result = AdjudicationResult(admitted=False)
    evidence = {e.evidence_id: e for e in evidence_store.load()}

    if candidate.generation <= parent.generation:
        result.reasons.append("generation did not advance")
        return result
    if candidate.lineage_id != parent.lineage_id:
        result.reasons.append("lineage mismatch")
        return result

    measured_classes = {EvidenceClass.LOCAL_MEASURED, EvidenceClass.EXTERNAL_MEASURED, EvidenceClass.INDEPENDENT_VERIFIED}
    for name, c in candidate.envelope.claims.items():
        if any(evidence.get(eid) is None or evidence[eid].evidence_class not in measured_classes for eid in c.evidence_ids):
            result.reasons.append(f"claim {name} lacks measured evidence")
            return result

    for name, p in parent.envelope.claims.items():
        c = candidate.envelope.get(name)
        if c is not None and _worse(c, p):
            result.regressions.append(name)

    for name, c in candidate.envelope.claims.items():
        p = parent.envelope.get(name)
        if p is None:
            if c.direction == Direction.BOOLEAN_TRUE and c.value < 1:
                continue
            result.improvements.append(f"new:{name}")
        elif _better(c, p):
            result.improvements.append(f"better:{name}")

    if result.regressions:
        result.reasons.append("measured capability regression detected")
        return result
    if not result.improvements:
        result.reasons.append("no measured capability expansion")
        return result

    new_exec_ids = set(candidate.executable_capabilities) - set(parent.executable_capabilities)
    if not new_exec_ids:
        result.reasons.append("no new executable capability exposed by successor")
        return result

    # External actions cannot be promoted from local-only evidence.
    for cap_id in sorted(new_exec_ids):
        spec = candidate.executable_capabilities[cap_id]
        if spec.get("type") != "orchestrated_connector":
            continue
        eids = tuple(spec.get("evidence_ids") or ())
        if not eids:
            result.reasons.append(f"external capability {cap_id} lacks evidence binding")
            return result
        classes = {evidence[eid].evidence_class for eid in eids if eid in evidence}
        if not classes or not classes.issubset({EvidenceClass.EXTERNAL_MEASURED, EvidenceClass.INDEPENDENT_VERIFIED}):
            result.reasons.append(f"external capability {cap_id} is not externally measured")
            return result
        required = spec.get("required_evidence_class")
        if required and EvidenceClass(required) not in classes:
            result.reasons.append(f"external capability {cap_id} misses required evidence class")
            return result

    result.admitted = True
    if any(candidate.executable_capabilities[c].get("type") == "orchestrated_connector" for c in new_exec_ids):
        result.reasons.append("measured envelope expanded with externally evidenced executable action space")
    else:
        result.reasons.append("measured envelope expanded and executable action space increased")
    return result
