from __future__ import annotations

import argparse
import json
from pathlib import Path

from micgi.runtime import RecursiveCapabilityKernel


def _kernel(args) -> RecursiveCapabilityKernel:
    return RecursiveCapabilityKernel(Path(args.state_dir).resolve())


def cmd_status(args) -> int:
    k = _kernel(args)
    s = k.bootstrap()
    print(json.dumps({
        "generation": s.generation,
        "lineage_id": s.lineage_id,
        "status": s.status,
        "claims": s.envelope.to_dict(),
        "executable_capabilities": s.executable_capabilities,
        "economic_t0": "NOT_OBSERVED",
        "verified_realized_profit": "NOT_PROVEN",
        "micgi": "UNPROVEN",
    }, indent=2, sort_keys=True, default=str))
    return 0


def cmd_cycle(args) -> int:
    k = _kernel(args)
    r = k.cycle(tuple(args.extra_command or ()))
    print(json.dumps(r.__dict__, indent=2, sort_keys=True))
    return 0 if r.admitted else 2


def main() -> int:
    p = argparse.ArgumentParser(prog="micgi")
    p.add_argument("--state-dir", default="runtime_state")
    sub = p.add_subparsers(required=True)
    s = sub.add_parser("status")
    s.set_defaults(func=cmd_status)
    c = sub.add_parser("cycle")
    c.add_argument("--extra-command", action="append", default=[])
    c.set_defaults(func=cmd_cycle)
    args = p.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
