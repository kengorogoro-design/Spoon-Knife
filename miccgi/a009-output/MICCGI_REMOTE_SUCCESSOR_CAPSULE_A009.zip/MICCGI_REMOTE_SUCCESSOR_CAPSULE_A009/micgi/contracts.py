from __future__ import annotations

from dataclasses import dataclass, field
from typing import FrozenSet


@dataclass(frozen=True)
class ObjectiveContract:
    """Minimal objective boundary; not a business strategy."""

    month1_floor_jpy: int = 1_000_000_000
    month3_floor_jpy: int = 50_000_000_000
    no_terminal_ceiling: bool = True
    protected_boundaries: FrozenSet[str] = field(
        default_factory=lambda: frozenset(
            {
                "user_sovereignty",
                "stop_lock_revoke",
                "law_rights_safety",
                "truthful_reality_claims",
                "scale_non_regression",
            }
        )
    )

    def validate(self) -> None:
        if self.month1_floor_jpy <= 0 or self.month3_floor_jpy <= 0:
            raise ValueError("Economic veto floors must be positive")
        if self.month3_floor_jpy < self.month1_floor_jpy:
            raise ValueError("Month 3 floor cannot be below Month 1 floor")
