from __future__ import annotations

from dataclasses import dataclass
import shutil

from micgi.adapters.local_machine import CommandAdapter


@dataclass(frozen=True)
class DiscoveryCandidate:
    command: str
    rationale: str


# This is deliberately a seed, not a constitutional ontology. The discovery engine can
# accept additional candidates at runtime and future successors can replace this mechanism.
DEFAULT_CANDIDATES = (
    DiscoveryCandidate("git", "versioned software construction and external code integration"),
    DiscoveryCandidate("ffmpeg", "high-throughput media transformation"),
    DiscoveryCandidate("python", "general executable software substrate"),
)


def discover_command_adapters(extra: tuple[str, ...] = ()) -> list[CommandAdapter]:
    names = [c.command for c in DEFAULT_CANDIDATES] + list(extra)
    seen: set[str] = set()
    adapters: list[CommandAdapter] = []
    for name in names:
        if name in seen or not shutil.which(name):
            continue
        seen.add(name)
        if name == "python":
            args = ("-V",)
        elif name == "ffmpeg":
            args = ("-version",)
        else:
            args = ("--version",)
        adapters.append(CommandAdapter(name, args))
    return adapters
