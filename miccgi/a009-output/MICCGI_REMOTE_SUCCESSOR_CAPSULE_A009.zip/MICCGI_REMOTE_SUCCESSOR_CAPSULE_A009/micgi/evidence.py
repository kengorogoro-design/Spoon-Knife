from __future__ import annotations

from dataclasses import dataclass, asdict
from enum import Enum
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable
import json
import time


class EvidenceClass(str, Enum):
    SYNTHETIC = "synthetic"
    LOCAL_MEASURED = "local_measured"
    EXTERNAL_MEASURED = "external_measured"
    INDEPENDENT_VERIFIED = "independent_verified"


@dataclass(frozen=True)
class Evidence:
    evidence_id: str
    evidence_class: EvidenceClass
    source: str
    claim: str
    observed_at_unix: float
    payload_sha256: str
    payload: dict[str, Any]

    @staticmethod
    def create(
        evidence_class: EvidenceClass,
        source: str,
        claim: str,
        payload: dict[str, Any],
    ) -> "Evidence":
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        digest = sha256(raw).hexdigest()
        observed = time.time()
        eid = sha256(f"{evidence_class}|{source}|{claim}|{observed}|{digest}".encode()).hexdigest()[:24]
        return Evidence(eid, evidence_class, source, claim, observed, digest, payload)


class EvidenceStore:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, evidence: Evidence) -> None:
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(asdict(evidence), sort_keys=True, default=str) + "\n")

    def load(self) -> list[Evidence]:
        if not self.path.exists():
            return []
        out: list[Evidence] = []
        for line in self.path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            d = json.loads(line)
            d["evidence_class"] = EvidenceClass(d["evidence_class"])
            out.append(Evidence(**d))
        return out

    def by_ids(self, ids: Iterable[str]) -> list[Evidence]:
        wanted = set(ids)
        return [e for e in self.load() if e.evidence_id in wanted]
