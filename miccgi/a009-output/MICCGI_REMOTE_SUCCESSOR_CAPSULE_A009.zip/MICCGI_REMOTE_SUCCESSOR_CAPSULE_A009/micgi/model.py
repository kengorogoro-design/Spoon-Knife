from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any
import json


class Direction(str, Enum):
    HIGHER_IS_BETTER = "higher"
    LOWER_IS_BETTER = "lower"
    BOOLEAN_TRUE = "true"


@dataclass(frozen=True)
class CapabilityClaim:
    """Open-schema measured capability claim.

    No fixed global capability ontology is imposed. New capability names can be created
    whenever Reality and the objective make them useful.
    """

    name: str
    value: float
    unit: str
    direction: Direction
    evidence_ids: tuple[str, ...]
    durability: str = "runtime"
    objective_relevance: str = "indirect"
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class CapabilityEnvelope:
    claims: dict[str, CapabilityClaim] = field(default_factory=dict)

    def put(self, claim: CapabilityClaim) -> None:
        self.claims[claim.name] = claim

    def get(self, name: str) -> CapabilityClaim | None:
        return self.claims.get(name)

    def to_dict(self) -> dict[str, Any]:
        return {k: asdict(v) for k, v in sorted(self.claims.items())}


@dataclass
class GenerationState:
    generation: int
    lineage_id: str
    envelope: CapabilityEnvelope
    executable_capabilities: dict[str, dict[str, Any]] = field(default_factory=dict)
    status: str = "CANDIDATE"
    notes: list[str] = field(default_factory=list)

    def to_json(self) -> str:
        return json.dumps(asdict(self), sort_keys=True, indent=2, default=str)
