from __future__ import annotations

from dataclasses import asdict
from pathlib import Path
import json

from micgi.model import CapabilityClaim, CapabilityEnvelope, Direction, GenerationState


class StateStore:
    def __init__(self, root: Path):
        self.root = root
        self.root.mkdir(parents=True, exist_ok=True)
        self.current_path = self.root / "current_state.json"
        self.history_path = self.root / "history.jsonl"

    def save(self, state: GenerationState) -> None:
        raw = asdict(state)
        self.current_path.write_text(json.dumps(raw, indent=2, sort_keys=True, default=str), encoding="utf-8")
        with self.history_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(raw, sort_keys=True, default=str) + "\n")

    def load(self) -> GenerationState | None:
        if not self.current_path.exists():
            return None
        d = json.loads(self.current_path.read_text(encoding="utf-8"))
        claims = {}
        for name, c in d["envelope"]["claims"].items():
            c["direction"] = Direction(c["direction"])
            c["evidence_ids"] = tuple(c["evidence_ids"])
            claims[name] = CapabilityClaim(**c)
        d["envelope"] = CapabilityEnvelope(claims)
        return GenerationState(**d)
