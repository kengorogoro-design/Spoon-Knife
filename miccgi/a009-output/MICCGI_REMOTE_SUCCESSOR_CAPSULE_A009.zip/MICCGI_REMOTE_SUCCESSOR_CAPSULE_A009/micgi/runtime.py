from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import uuid

from micgi.adjudication import AdjudicationResult, adjudicate_successor
from micgi.adapters.local_machine import LocalMachineAdapter
from micgi.adapters.manifest import discover_manifest_adapters
from micgi.adapters.external_receipt import discover_external_receipt_adapters
from micgi.contracts import ObjectiveContract
from micgi.discovery import discover_command_adapters
from micgi.evidence import EvidenceStore
from micgi.model import CapabilityEnvelope, GenerationState
from micgi.persistence import StateStore


@dataclass
class CycleResult:
    parent_generation: int
    candidate_generation: int
    admitted: bool
    improvements: list[str]
    reasons: list[str]


class RecursiveCapabilityKernel:
    def __init__(self, state_root: Path):
        self.contract = ObjectiveContract()
        self.contract.validate()
        self.state_store = StateStore(state_root)
        self.evidence_store = EvidenceStore(state_root / "evidence.jsonl")

    def bootstrap(self) -> GenerationState:
        existing = self.state_store.load()
        if existing:
            return existing
        env = CapabilityEnvelope()
        exec_caps: dict[str, dict] = {}
        probe = LocalMachineAdapter().probe()
        for e in probe.evidence:
            self.evidence_store.append(e)
        for c in probe.claims:
            env.put(c)
        exec_caps[probe.capability_id] = probe.executable_spec
        state = GenerationState(
            generation=0,
            lineage_id=f"MICCGI-RC-{uuid.uuid4().hex[:12]}",
            envelope=env,
            executable_capabilities=exec_caps,
            status="ACTIVE_UNPROVEN",
            notes=["Economic T0 not observed; no MICCGI admission credit."],
        )
        self.state_store.save(state)
        return state

    def build_candidate(self, extra_commands: tuple[str, ...] = ()) -> GenerationState:
        parent = self.bootstrap()
        env = CapabilityEnvelope(dict(parent.envelope.claims))
        exec_caps = dict(parent.executable_capabilities)

        adapters = list(discover_command_adapters(extra_commands))
        adapters.extend(discover_manifest_adapters(self.state_store.root / "capability_manifests"))
        adapters.extend(discover_external_receipt_adapters(self.state_store.root / "external_receipts"))
        for adapter in adapters:
            if adapter.capability_id in exec_caps:
                continue
            probe = adapter.probe()
            for e in probe.evidence:
                self.evidence_store.append(e)
            if not probe.usable:
                continue
            for c in probe.claims:
                env.put(c)
            exec_caps[probe.capability_id] = probe.executable_spec

        return GenerationState(
            generation=parent.generation + 1,
            lineage_id=parent.lineage_id,
            envelope=env,
            executable_capabilities=exec_caps,
            status="CANDIDATE",
            notes=["Candidate created from measured capability discovery; no economic credit implied."],
        )

    def cycle(self, extra_commands: tuple[str, ...] = ()) -> CycleResult:
        parent = self.bootstrap()
        candidate = self.build_candidate(extra_commands)
        result: AdjudicationResult = adjudicate_successor(parent, candidate, self.evidence_store)
        if result.admitted:
            candidate.status = "ACTIVE_UNPROVEN"
            candidate.notes.append("Promoted for measured capability expansion only; MICCGI remains UNPROVEN.")
            self.state_store.save(candidate)
        return CycleResult(parent.generation, candidate.generation, result.admitted, result.improvements, result.reasons)
