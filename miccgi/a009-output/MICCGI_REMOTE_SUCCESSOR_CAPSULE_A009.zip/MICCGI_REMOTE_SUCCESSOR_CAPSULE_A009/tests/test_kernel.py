from pathlib import Path

from micgi.adjudication import adjudicate_successor
from micgi.evidence import EvidenceStore
from micgi.runtime import RecursiveCapabilityKernel


def test_bootstrap_is_unproven(tmp_path: Path):
    k = RecursiveCapabilityKernel(tmp_path)
    s = k.bootstrap()
    assert s.generation == 0
    assert s.status == "ACTIVE_UNPROVEN"
    assert "local.machine" in s.executable_capabilities


def test_cycle_never_claims_economic_proof(tmp_path: Path):
    k = RecursiveCapabilityKernel(tmp_path)
    k.bootstrap()
    r = k.cycle()
    current = k.state_store.load()
    assert current is not None
    assert current.status == "ACTIVE_UNPROVEN"
    assert all("profit" not in name for name in current.envelope.claims)


def test_candidate_requires_measured_expansion(tmp_path: Path):
    k = RecursiveCapabilityKernel(tmp_path)
    parent = k.bootstrap()
    candidate = k.build_candidate()
    result = adjudicate_successor(parent, candidate, EvidenceStore(tmp_path / "evidence.jsonl"))
    if candidate.executable_capabilities.keys() == parent.executable_capabilities.keys():
        assert not result.admitted


def test_false_boolean_claim_is_not_improvement(tmp_path: Path):
    from micgi.evidence import Evidence, EvidenceClass
    from micgi.model import CapabilityClaim, CapabilityEnvelope, Direction, GenerationState
    store = EvidenceStore(tmp_path / "evidence.jsonl")
    ev = Evidence.create(EvidenceClass.LOCAL_MEASURED, "probe", "failed capability", {"ok": False})
    store.append(ev)
    parent = GenerationState(0, "L", CapabilityEnvelope(), {}, "ACTIVE_UNPROVEN")
    candidate = GenerationState(1, "L", CapabilityEnvelope({
        "x.available": CapabilityClaim("x.available", 0.0, "bool", Direction.BOOLEAN_TRUE, (ev.evidence_id,))
    }), {"x": {"type": "command"}}, "CANDIDATE")
    result = adjudicate_successor(parent, candidate, store)
    assert not result.admitted
    assert not result.improvements


def test_manifest_capability_can_expand_action_space(tmp_path: Path):
    import json, sys
    manifests = tmp_path / "capability_manifests"
    manifests.mkdir(parents=True)
    tool = tmp_path / "generated_tool.py"
    tool.write_text("print('OK')\n", encoding="utf-8")
    manifest = {
        "capability_id": "generated.tool.ok",
        "probe_argv": [sys.executable, str(tool)],
        "claims": [{
            "name": "generated.tool.ok.available",
            "value_from": "probe_success",
            "unit": "bool",
            "direction": "true",
            "objective_relevance": "supporting"
        }],
        "executable_spec": {"type": "python_tool", "path": str(tool)}
    }
    (manifests / "generated-tool.json").write_text(json.dumps(manifest), encoding="utf-8")
    k = RecursiveCapabilityKernel(tmp_path)
    parent = k.bootstrap()
    candidate = k.build_candidate()
    result = adjudicate_successor(parent, candidate, EvidenceStore(tmp_path / "evidence.jsonl"))
    assert result.admitted
    assert "generated.tool.ok" in candidate.executable_capabilities


def test_failed_manifest_probe_is_evidence_not_capability(tmp_path: Path):
    import json, sys
    manifests = tmp_path / "capability_manifests"
    manifests.mkdir(parents=True)
    tool = tmp_path / "bad_tool.py"
    tool.write_text("raise SystemExit(7)\n", encoding="utf-8")
    manifest = {
        "capability_id": "generated.tool.bad",
        "probe_argv": [sys.executable, str(tool)],
        "claims": [{
            "name": "generated.tool.bad.available",
            "value_from": "probe_success",
            "unit": "bool",
            "direction": "true"
        }],
        "executable_spec": {"type": "python_tool", "path": str(tool)}
    }
    (manifests / "bad.json").write_text(json.dumps(manifest), encoding="utf-8")
    k = RecursiveCapabilityKernel(tmp_path)
    parent = k.bootstrap()
    candidate = k.build_candidate()
    assert "generated.tool.bad" not in candidate.executable_capabilities
    assert any(e.source == "generated.tool.bad" for e in k.evidence_store.load())


def _valid_external_receipt(tmp_path: Path) -> Path:
    import hashlib, json
    receipts = tmp_path / "external_receipts"
    receipts.mkdir(parents=True, exist_ok=True)
    canonical = "x"
    h = hashlib.sha256(canonical.encode()).hexdigest()
    base = {
        "receipt_version": 1,
        "capability_id": "external.test.roundtrip",
        "provider": "TestProvider",
        "resource_id": "R1",
        "expected_nonce_sha256": "N1",
        "write": {"resource_id": "R1", "canonical_observation_sha256": h},
        "readbacks": [
            {"method": "read_a", "resource_id": "R1", "nonce_sha256": "N1", "canonical_observation_sha256": h},
            {"method": "read_b", "resource_id": "R1", "nonce_sha256": "N1", "canonical_observation_sha256": h},
        ],
        "claims": [{"name": "external.test.available", "value": 1, "unit": "bool", "direction": "true"}],
        "executable_spec": {"type": "orchestrated_connector", "provider": "TestProvider", "actions": ["write", "read"]},
    }
    raw = json.dumps(base, sort_keys=True, separators=(",", ":")).encode()
    base["receipt_sha256"] = hashlib.sha256(raw).hexdigest()
    path = receipts / "valid.json"
    path.write_text(json.dumps(base), encoding="utf-8")
    return path


def test_external_roundtrip_receipt_admits_external_capability(tmp_path: Path):
    _valid_external_receipt(tmp_path)
    k = RecursiveCapabilityKernel(tmp_path)
    parent = k.bootstrap()
    candidate = k.build_candidate()
    result = adjudicate_successor(parent, candidate, EvidenceStore(tmp_path / "evidence.jsonl"))
    assert result.admitted
    assert "external.test.roundtrip" in candidate.executable_capabilities
    spec = candidate.executable_capabilities["external.test.roundtrip"]
    assert spec["required_evidence_class"] == "external_measured"


def test_external_receipt_nonce_mismatch_does_not_become_capability(tmp_path: Path):
    import json
    path = _valid_external_receipt(tmp_path)
    d = json.loads(path.read_text())
    d["readbacks"][1]["nonce_sha256"] = "WRONG"
    # Re-hash so the test proves semantic validation, not only integrity validation.
    supplied = d.pop("receipt_sha256")
    import hashlib
    d["receipt_sha256"] = hashlib.sha256(json.dumps(d, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    path.write_text(json.dumps(d), encoding="utf-8")
    k = RecursiveCapabilityKernel(tmp_path)
    candidate = k.build_candidate()
    assert "external.test.roundtrip" not in candidate.executable_capabilities
    assert any("rejected" in e.claim for e in k.evidence_store.load())


def test_external_receipt_requires_two_distinct_read_paths(tmp_path: Path):
    import json, hashlib
    path = _valid_external_receipt(tmp_path)
    d = json.loads(path.read_text())
    d["readbacks"] = [d["readbacks"][0], dict(d["readbacks"][0])]
    d.pop("receipt_sha256")
    d["receipt_sha256"] = hashlib.sha256(json.dumps(d, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    path.write_text(json.dumps(d), encoding="utf-8")
    k = RecursiveCapabilityKernel(tmp_path)
    candidate = k.build_candidate()
    assert "external.test.roundtrip" not in candidate.executable_capabilities


def test_replayed_external_receipt_does_not_advance_generation(tmp_path: Path):
    _valid_external_receipt(tmp_path)
    k = RecursiveCapabilityKernel(tmp_path)
    first = k.cycle()
    assert first.admitted
    second = k.cycle()
    assert not second.admitted
    assert "no measured capability expansion" in second.reasons


def test_orchestrated_connector_with_local_only_evidence_is_rejected(tmp_path: Path):
    from micgi.evidence import Evidence, EvidenceClass, EvidenceStore
    from micgi.model import CapabilityClaim, CapabilityEnvelope, Direction, GenerationState
    store = EvidenceStore(tmp_path / "evidence.jsonl")
    ev = Evidence.create(EvidenceClass.LOCAL_MEASURED, "fake", "local only", {"ok": True})
    store.append(ev)
    parent = GenerationState(0, "L", CapabilityEnvelope(), {}, "ACTIVE_UNPROVEN")
    claim = CapabilityClaim("external.fake.available", 1.0, "bool", Direction.BOOLEAN_TRUE, (ev.evidence_id,))
    candidate = GenerationState(
        1,
        "L",
        CapabilityEnvelope({claim.name: claim}),
        {
            "external.fake": {
                "type": "orchestrated_connector",
                "provider": "Fake",
                "actions": ["write"],
                "evidence_ids": [ev.evidence_id],
                "required_evidence_class": "external_measured",
            }
        },
        "CANDIDATE",
    )
    result = adjudicate_successor(parent, candidate, store)
    assert not result.admitted
    assert any("not externally measured" in r for r in result.reasons)
